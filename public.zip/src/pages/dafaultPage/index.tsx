const DefaultPage = () => {
  return <>Dafault page</>;
};

export default DefaultPage;
