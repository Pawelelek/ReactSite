export default function NotFound() {
  return <h1>NotFound</h1>;
}
