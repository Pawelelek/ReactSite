import * as UserActionCreator from "./userActions"

export default {
    ...UserActionCreator
}